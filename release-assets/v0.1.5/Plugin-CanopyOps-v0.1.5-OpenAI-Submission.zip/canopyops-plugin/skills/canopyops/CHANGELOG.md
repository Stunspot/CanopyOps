# Changelog

## 0.1.5

- Replace the generic greenhouse mark with a product-specific cultivation-canopy operations-grid icon.
- Add governed archives for the complete Augment, Codex plugin, and standalone skill, with hash and extraction-parity custody.
- Make plugin readiness, archive locations, and backup custody explicit in customer and release documentation.

## 0.1.4

- Bring customer-facing release, privacy, security, installation, and support evidence into one current version boundary.
- Advance evaluation manifests to the package version and add regression checks for version custody and distribution parity.
- Add a reproducible release manifest and rebuild the Claude distribution from the canonical skill tree.

## 0.1.3

- Add a portable one-skill Claude.ai upload archive and current non-coder installation path.
- Shorten skill discovery metadata to the current Claude limit without changing the operating kernel.
- Verify Codex and Claude Builder profiles and byte parity across standalone, plugin, and archive copies.

## 0.1.2

- Finalize the public GitHub distribution and remove stale private-release language from customer-facing records.
- Regularize the Codex plugin version and public download packaging.
- Preserve the v0.1.1 runtime behavior, safety boundaries, evaluation cases, and deterministic utilities unchanged.

## 0.1.1

- Preserve user-supplied targets as comparison values until stage, scope, tolerance, source, and approval establish an active target.
- Treat occupied active CO2 and life-safety alarms as emergency/evacuation states, never approval candidates for bypass or continued work.
- Add bounded qualified-professional redirects for adjacent out-of-scope requests.
- Add the promised Claude Code runtime adapter and direct installation guidance.
- Adopt brand-preserving public terms: `CC-BY-ND-4.0` for authored Augment material, MIT for scripts and schemas, plus limited trademark permission for authentic redistribution.

## 0.1.0

- Initial CanopyOps skill system.
- Five cultivation operations workflows and independent release review.
- Evidence, source-quality, compliance-verification, and safety doctrine.
- Facility, crop, incident, plan, harvest, CAPA, risk, and handoff artifacts.
- Deterministic VPD, DLI, irrigation, normalization, validation, linting, and source-freshness utilities.
- Four demonstrations and canonical behavioral evaluations.
